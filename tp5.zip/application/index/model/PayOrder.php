<?php
/**
 * Created by PhpStorm.
 * User: 10
 * Date: 2019/7/30
 * Time: 10:08
 */

namespace app\index\model;


use think\Model;

class PayOrder extends Model
{

}