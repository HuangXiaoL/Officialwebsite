<?php /*a:1:{s:81:"F:\phpstudy\PHPTutorial\WWW\mypay\tp5\application\index\view\index\userinfo1.html";i:1565764754;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="http://www.mypay.com/static/assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="http://www.mypay.com/static/assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>赢时国际</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <!-- CSS Files -->
    <link href="http://www.mypay.com/static/assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="http://www.mypay.com/static/assets/css/now-ui-kit.css?v=1.1.0" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="http://www.mypay.com/static/assets/css/demo.css" rel="stylesheet" />
    <!-- Canonical SEO -->
    <link rel="canonical" href="" />
    <!--  Social tags      -->
    <meta name="keywords" content="">
    <meta name="description" content="">
    
    
    
</head>

<body class="profile-page sidebar-collapse">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg bg-primary fixed-top navbar-transparent " color-on-scroll="400">
        <div class="container">
            <div class="dropdown button-dropdown">

                    <span class="button-bar"></span>
                    <span class="button-bar"></span>
                    <span class="button-bar"></span>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-header">Dropdown header</a>
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#">Something else here</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">Separated link</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">One more separated link</a>
                </div>
            </div>
            <div class="navbar-translate">
                <a class="navbar-brand" href="index" rel="tooltip" title="" data-placement="bottom">
                    官网首页
                </a>
                <button class="navbar-toggler navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-bar bar1"></span>
                    <span class="navbar-toggler-bar bar2"></span>
                    <span class="navbar-toggler-bar bar3"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse justify-content-end" data-nav-image="http://www.mypay.com/static/assets/img/blurred-image-1.jpg">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="#">个人中心</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="news">新闻资讯</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="https://xmvip.vip/L99vQ2">软件下载</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="out">退出登录</a>
                    </li>

                </ul>
            </div>
        </div>
    </nav>
    <!-- End Navbar -->
    <div class="wrapper">
        <div class="page-header page-header-small" filter-color="orange">
            <div class="page-header-image" data-parallax="true" style="background-image: url('http://www.mypay.com/static/assets/img/bg5.jpg');">
            </div>
            <div class="container">
                <div class="content-center">
                    <div class="photo-container">
                        <img src="http://www.mypay.com/static/assets/img/default-avatar.png" alt="">
                    </div>
                    <h3 class="title"><?php echo $_SESSION['userData']['nickname'];?></h3>
                    <p class="category">VIP 客户</p>
                    <div class="content">
                        <div class="social-description">
                            <h2><?php echo $_SESSION['userData']['profit_account'];?></h2>
                            <p>盈利金额（元）</p>
                        </div>

                        <div class="social-description">
                            <h2><?php echo $_SESSION['userData']['account'];?></h2>
                            <p>当前余额（元）</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="section">
            <div class="container">
                <div class="button-container">
                    <a href="#button" class="btn btn-primary btn-round btn-lg" style="font-size: 2em">入&nbsp;&nbsp;&nbsp;金</a>



                </div>
                  <div class="row">

                    <!-- Tab panes -->
                    <div class="tab-content gallery">
                        <div class="tab-pane active" id="home" role="tabpanel">
                            <div class="col-md-10 ml-auto mr-auto">
                                <div class="row collections">
                                    <div class="col-md-6">
                                        <img src="http://www.mypay.com/static/picture/g1.png" alt="" class="img-raised">
                                        <img src="http://www.mypay.com/static/picture/g2.png" alt="" class="img-raised">
                                    </div>
                                    <div class="col-md-6">
                                        <img src="http://www.mypay.com/static/picture/g3.png" alt="" class="img-raised">
                                        <img src="http://www.mypay.com/static/picture/g1.png" alt="" class="img-raised">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="profile" role="tabpanel">
                            <div class="col-md-10 ml-auto mr-auto">
                                <div class="row collections">
                                    <div class="col-md-6">
                                        <img src="http://www.mypay.com/static/assets/img/bg6.jpg" class="img-raised">
                                        <img src="http://www.mypay.com/static/assets/img/bg11.jpg" alt="" class="img-raised">
                                    </div>
                                    <div class="col-md-6">
                                        <img src="http://www.mypay.com/static/assets/img/bg7.jpg" alt="" class="img-raised">
                                        <img src="http://www.mypay.com/static/assets/img/bg8.jpg" alt="" class="img-raised">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="messages" role="tabpanel">
                            <div class="col-md-10 ml-auto mr-auto">
                                <div class="row collections">
                                    <div class="col-md-6">
                                        <img src="http://www.mypay.com/static/assets/img/bg3.jpg" alt="" class="img-raised">
                                        <img src="http://www.mypay.com/static/assets/img/bg8.jpg" alt="" class="img-raised">
                                    </div>
                                    <div class="col-md-6">
                                        <img src="http://www.mypay.com/static/assets/img/bg7.jpg" alt="" class="img-raised">
                                        <img src="http://www.mypay.com/static/assets/img/bg6.jpg" class="img-raised">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="footer footer-default">
            <div class="container">
                <nav>
                    <ul>
                        <li>
                            <a href="index">
                               官网首页
                            </a>
                        </li>
                        <li>
                            <a href="news">
                                新闻资讯
                            </a>
                        </li>
                        <li>
                            <a href="#">
                               个人中心
                            </a>
                        </li>
                        <li>
                            <a href="https://xmvip.vip/L99vQ2">
                                软件下载
                            </a>
                        </li>
                    </ul>
                </nav>
                <div class="copyright">
                    &copy;
                    <script>
                        document.write(new Date().getFullYear())
                    </script>风险提示：

                    期市有风险，投资需谨慎

                    市场风险莫测，务请谨慎行事！</a>
                </div>
            </div>
        </footer>
    </div>
</body>
<!--   Core JS Files   -->
<script src="http://www.mypay.com/static/assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="http://www.mypay.com/static/assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="http://www.mypay.com/static/assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="http://www.mypay.com/static/assets/js/plugins/bootstrap-switch.js"></script>
<!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
<script src="http://www.mypay.com/static/assets/js/plugins/nouislider.min.js" type="text/javascript"></script>
<!--  Plugin for the DatePicker, full documentation here: https://github.com/uxsolutions/bootstrap-datepicker -->
<script src="http://www.mypay.com/static/assets/js/plugins/bootstrap-datepicker.js" type="text/javascript"></script>
<!-- Share Library etc -->
<script src="http://www.mypay.com/static/assets/js/plugins/jquery.sharrre.js" type="text/javascript"></script>
<!-- Control Center for Now Ui Kit: parallax effects, scripts for the example pages etc -->
<script src="http://www.mypay.com/static/assets/js/now-ui-kit.js?v=1.1.0" type="text/javascript"></script>

</html>