<?php /*a:1:{s:76:"F:\phpstudy\PHPTutorial\WWW\mypay\tp5\application\index\view\index\news.html";i:1565763412;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>赢时国际</title>
</head>
<body style="height: 59em">

<iframe src="https://www.jin10.com/?url=cdn/" width="100%" height="100%" style="border: none;"></iframe>
</body>
</html>