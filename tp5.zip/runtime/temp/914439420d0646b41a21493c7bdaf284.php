<?php /*a:1:{s:78:"F:\phpstudy\PHPTutorial\WWW\mypay\tp5\application\index\view\index\paynum.html";i:1564997552;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no">
  <link rel="stylesheet" href="http://www.mypay.com/static/css/bootstrap.min.css">
  <link rel="stylesheet" href="http://www.mypay.com/static/css/style.css">
  <title>支付</title>
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="container_logo">
        <div class="play col-xs-10 col-sm-10 col-md-10 col-lg-10">
          <img src="http://www.mypay.com/static/images/logo.png" />
        </div>
      </div>
    </div>
    <form action="simulated" method="post">
      <div class="row">
        <div class="play col-xs-10 col-sm-10 col-md-10 col-lg-10">
          <div class="form-group">

            <h4>充值金额</h4>
            <div class="number_amount">

              <label>￥</label>
              <input type="number" name="amount" readonly="readonly">
              <input type="hidden" class="getId" name="id">
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="quick_amount col-xs-10 col-sm-10 col-md-10 col-lg-10">
          <p class="col-xs-3 col-sm-3 col-md-3 col-lg-3" data-item='0.01'>0.01</p>
          <p class="col-xs-3 col-sm-3 col-md-3 col-lg-3" data-item='3000'>3000</p>
          <p class="col-xs-3 col-sm-3 col-md-3 col-lg-3" data-item='5000'>5000</p>
          <p class="col-xs-3 col-sm-3 col-md-3 col-lg-3" data-item='10000'>10000</p>
          <p class="col-xs-3 col-sm-3 col-md-3 col-lg-3" data-item='30000'>30000</p>
          <p class="col-xs-3 col-sm-3 col-md-3 col-lg-3" data-item='50000'>50000</p>
        </div>
      </div>
      <div class="row">
        <div class="_submit col-xs-10 col-sm-10 col-md-10 col-lg-10">
          <input type="submit" value="充值" class="btn btn-primary submit-amount">
        </div>
      </div>
    </form>
  </div>
  </div>
  <div class="modal fade" tabindex="-1" role="dialog" id='exampleModal'>
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
          <h4 class="modal-title">提示</h4>
        </div>
        <div class="modal-body">
          <p>输入金额不能超出5000元</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">确定</button>
        </div>
      </div>
    </div>
  </div>
  <div class="mask"></div>
</body>
<script src="http://www.mypay.com/static/js/jquery.min.js"></script>
<script src="http://www.mypay.com/static/js/bootstrap.min.js"></script>
<script>
var $amountInput = $('[type="number"]');
var amount = '';
var $getId = $('[type="hidden"]');
var getparse=ParaMeter();
$getId.val(getparse.id);
$(".quick_amount p").off("click").on("click", function () {
  amount = $(this).text();
  if (!$(this).hasClass('active')) {
    $(this).addClass('active').siblings().removeClass('active');
    $amountInput.val(amount);
  } else {
    $(this).removeClass('active');
    $amountInput.val('');
  }
})
$amountInput.on('input propertychange', function () {
  if ($(this).val() > 5000) {
    $('#exampleModal').modal('show')
  }
  if($(this).val()!==$('.quick_amount p.active').text()){
    $('.quick_amount p').removeClass('active');
  }
})
$('#exampleModal').on('hidden.bs.modal', function (e) {
  $amountInput.val(5000);
})
function ParaMeter()
{
  var obj={};
  var arr=location.href.substring(location.href.lastIndexOf('?')+1).split("&");
  for(var i=0;i < arr.length;i++){
  var aa=arr[i].split("=");
  obj[aa[0]]=aa[1];
}
  return obj;
}
</script>

</html>