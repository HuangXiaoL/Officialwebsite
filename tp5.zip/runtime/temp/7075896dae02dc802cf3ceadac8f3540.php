<?php /*a:1:{s:77:"F:\phpstudy\PHPTutorial\WWW\mypay\tp5\application\index\view\index\index.html";i:1565774124;}*/ ?>
<!doctype html>
<html>
<head>
<title>赢时国际</title>
<meta name="Keywords" content="" >
<meta name="Description" content="" >
<meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=0">
<meta name="author" content="ASPCMS! Team and Chancoo UI Team" />
<meta name="copyright" content="2006-2013 Chancoo Inc." />
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<META http-equiv=Content-Type content="text/html; charset=utf-8">
<META content="MSHTML 6.00.3790.4807" name=GENERATOR>

</head>

<body>



<link rel="stylesheet" type="text/css" href="http://www.mypay.com/static/css/index.css" />
<link rel="stylesheet" type="text/css" href="http://www.mypay.com/static/css/idangerous.swiper.css" />
<script src="http://www.mypay.com/static/js/jquery.min.js" type="text/javascript" charset="utf-8"></script>



<div class="heads">
    <div class="heads-bao">
   

        <div class="logo">

          <div style="float:left; width:80px;overflow: hidden;">
            <img src="http://www.mypay.com/static/picture/201711091758389646.png">
          </div>
          
          <div style="float:left; font-size:25px; height:60px; width:auto; color:#3e3e3e;">
             <h3 style="margin-top:4px;height:19px;letter-spacing:6px;">赢时国际</h3>
             <font style="clear:both; font-size:9px;letter-spacing:1px;">WINNING INTERTATIONAL</font>
          </div>

        </div>


         <div class="nav">
          <ul id="menu" class="menu"> 
                      
   
          <!--<li><a href="https://xmvip.vip/L99vQ2">软件下载</a>-->
                <!--&lt;!&ndash;<ul>-->
                  <!--<li><a href="/index.php/index/index/news">��������</a></li>-->
                  <!--<li><a href="#">��Ѷ��̬</a></li>-->
                  <!--<li><a href="#">��Ѷ��̬</a></li>-->
                <!--</ul>&ndash;&gt;-->
          <!--</li>-->


 
           <!--<li><a href="/web/qhtzi/about/?73.html">期货商品</a></li>-->


 
           <!--<li><a href="/web/qhtzi/about/?62.html">公司业务</a></li>-->


 
           <li><a href="/index.php/index/index/login">账户登录</a></li>


 
           <li><a href="/index.php/index/index/news">新闻资讯</a></li>


 
           <li><a href="#">网站首页</a></li>


           
       
          </ul>
        
         </div>
         
         <!--<div class="server_kf">-->
            <!--<em>&#23458;&#26381;&#28909;&#32447;</em>-->
            <!--<b>150-0050-3871</b>-->
	     <!--</div>-->
         
    </div>
</div>


<!--
<script type="text/javascript">

  var urlstr = location.href;

  //alert((urlstr + '/').indexOf($(this).attr('href')));

  var urlstatus=false;

  $("#menu a").each(function () {

    if ((urlstr + '/').indexOf($(this).attr('href')) > -1&&$(this).attr('href')!='') {

      $(this).addClass('first'); urlstatus = true;

    } else {

      $(this).removeClass('first');

    }

  });

  if (!urlstatus) {$("#menu a").eq(0).addClass('first'); }

</script>

-->


<script type="text/javascript">

$(document).ready(function(){  
    $('.menu li a').each(function(){  
        if($($(this))[0].href==String(window.location))  
            $(this).parent().addClass('first');  
    });  
})  
   

</script>











<!--banner-->
<div class="in_banner">

   <div class="swiper-container">

        <div class="swiper-wrapper">



                        <div class="swiper-slide"><span><img src="http://www.mypay.com/static/picture/201712201610526649.jpg"></span></div>



                        <div class="swiper-slide"><span><img src="http://www.mypay.com/static/picture/201712201610593224.jpg"></span></div>



                        <div class="swiper-slide"><span><img src="http://www.mypay.com/static/picture/201711091052159264.png"></span></div>



                        <div class="swiper-slide"><span><img src="http://www.mypay.com/static/picture/201712201629222038.jpg"></span></div>

 

                    </div>

        <div class="pagination"></div>

    </div>

</div>

<!--chanPin-->

<div class="chanpin"> 
  <div class="chanpin-b"> 
      <div class="chanpin-li"> 
       <ul>
        <li>
            <h5>国内期货行情</h5>
		    <i id="baitang">3818.00</i>
            <div class="xian"></div>
            <div class="jz1" id="baitanghig">涨跌最高价格：4035.00</div>
            <div class="jz2">白糖期货</div>
            <div class="jz3" id="baitanglow">涨跌最低价格：3851.00</div>

        </li>
        <li class="lima">
            <h5>国际期货行情</h5>
		    <i id="huangjin">4035.00</i>
            <div class="xian"></div>
            <div class="jz1" id="huangjinhig">涨跌最高价格：4061.00</div>
            <div class="jz2">黄金期货</div>
            <div class="jz3" id="huangjinlow">涨跌最低价格：4066.00</div>

        </li>
        <li>
            <h5>能源化工期货行情</h5>
		    <i id="yuanyou">2528.00</i>
            <div class="xian"></div>
            <div class="jz1" id="yuanyouhig">涨跌最高价格：2620.00</div>
            <div class="jz2">原油期货</div>
            <div class="jz3" id="yuanyoulow">涨跌最低价格：2618.00</div>

        </li>
       </ul>
    
      </div>
  </div>
</div>

<!--/index.php/index/index/news-->
<div class="xinwen">
  <div class="xinwenl">
     <div class="xinwenl_img">
      <div class="sanjiao"></div> 
      <img src="http://www.mypay.com/static/picture/news.png">
     </div>
     <div class="xinwenl_ul">

       <h2>分析研究</h2>
       <a href="/index.php/index/index/news">MORE+</a>

       <ul id="liezi">

 
        <li><a href="/index.php/index/index/news">数据、传言“燃爆”钢铁圈！铁矿石尾盘急“泻” 只是...</a></li>
 
        <li><a href="/index.php/index/index/news">铁矿石突破近两年新高 钢企利润缩水产能仍上涨</a></li>
 
        <li><a href="/index.php/index/index/news">沪胶呈现弱势寻底格局</a></li>
 
        <li><a href="/index.php/index/index/news">铁矿石：供需关系改善 把握正向套利机会</a></li>
 
        <li><a href="/index.php/index/index/news">消息人士：铝生产商提出日本第四季度铝升水报价下跌</a></li>
 
        <li><a href="/index.php/index/index/news">铁矿石迎来阶段性做多机会</a></li>
 
        <li><a href="/index.php/index/index/news">大跌之后寻觅棉市慢牛踪迹 逢低布局01或05合约长...</a></li>
 
        <li><a href="/index.php/index/index/news">避险硬通货黄金为何“软”了</a></li>
 

       </ul>
     </div>
  </div>
  <div class="xinwenr">
       <div class="xinwenrr_ul">

       <h2>国际财经</h2>
       <a href="/index.php/index/index/news">MORE+</a>

       <ul id="liezi">

 
        <li><a href="/index.php/index/index/news">美联储降息布伦特原油减产 PTA会陪原油疯狂...</a></li>
 
        <li><a href="/index.php/index/index/news">外围“大戏”轮番上演 节后期市哪些板块会站上...</a></li>
 
        <li><a href="/index.php/index/index/news">黄金徘徊不前等待突破 这个金属却疯涨首破千四...</a></li>
 
        <li><a href="/index.php/index/index/news">中国对美投资大幅缩水</a></li>
 
        <li><a href="/index.php/index/index/news">煤炭卷土重来 全球需求料保持强劲</a></li>
 
        <li><a href="/index.php/index/index/news">中国将成俄大豆在远东交易所主要海外买家</a></li>
 
        <li><a href="/index.php/index/index/news">国际油价最新消息：原油供应增加忧虑+贸易局势...</a></li>
 
        <li><a href="/index.php/index/index/news">国际油价最新消息；供应中断风险加剧 俄罗斯全...</a></li>
 

       </ul>
     </div>
  </div>
  </div>
</div>

<!--rongYu-->
<div class="rongyu">
    <div class="rongyu-b">
       <div class="rongyu-img">
       </div>
        <div class="rongyu-ju">
        
          <div class="ju1">
             <h3>期 货 优 势<br/><span>Futures Advantage</span></h3>
             <ul>
             
              <li>
                 <span class="year">ONE</span>
                 <span class="mon">双向交易</span>
                 <p class="center">
                  可以做多，可以做空，做多或做空皆能赚钱。
                 </p>
              </li>
              <li>
                 <span class="year">TWO</span>
                 <span class="mon">T+0交易</span>
                 <p class="center">
                  日内交易，交易时间内随时开仓和平仓。
                 </p>
              </li>
              <li>
                 <span class="year">THREE</span>
                 <span class="mon">保证金制度</span>
                 <p class="center">
                  杠杆交易，在期货市场能获取10倍-20倍的盈利。
                 </p>
              </li>
              <li>
                 <span class="year">FOUR</span>
                 <span class="mon">交易费用低</span>
                 <p class="center">
                  期货交易国家不征收印花税等税费。
                 </p>
              </li>
              <li>
                 <span class="year">FIVE</span>
                 <span class="mon">期货产品众多</span>
                 <p class="center">
                  农产品、贵金属、能源化工交易商品丰富！
                 </p>
              </li>
              
             </ul>
           </div>
           
        </div>  
    </div>
</div>

<!--xuanze-->
<div class="xuanze">
 <ul>
  <li>
     <img src="http://www.mypay.com/static/picture/g1.png">
     <div class="xuanze-n">
        <h3>企业责任</h3>
        <h2>经国内正规交易所批准设立</h2>
        <p>从事金融期货、期权等金融衍生品交易与结算,服务多层次资本市场体系建设为宗旨。</p>

        <a href="/index.php/index/index/news">MORE+</a>

     </div>
  </li>
  <li class="xuanze-ts">
      <img src="http://www.mypay.com/static/picture/g2.png">
      <div class="xuanze-n">
        <h3>服务优势</h3>
        <h2>千位金牌专家坐镇为您解疑</h2>
        <p>坐拥众多经验丰富的金牌理财专家，在线为您答疑解惑，助您的成功之路更上一层。</p>

        <a href="/web/qhtzi/about/?62.html">MORE+</a>

     </div>
  </li>
  <li>
      <img src="http://www.mypay.com/static/picture/g3.png">
      <div class="xuanze-n">
        <h3>科技创新</h3>
        <h2>划时代炒股理财神器</h2>
        <p>为广大投资者量身定制的划时代理财神器，财富一手掌握！</p>

        <a href="/index.php/index/index/news">MORE+</a>
      </div>
  </li>
 </ul>
</div>

<div class="dyy">
	<div class="dyy-b">
	   <img src="http://www.mypay.com/static/picture/dyy.jpg">
    </div>
</div>

<!--foot-->


<script language="javascript"> 

function logout(){ 
if (confirm("系统检测您还未注册账户，请注册后查看更多！"))
{ 
window.location.href="/web/qhtzi/gbook/"
} 
} 

</script> 
<!--<input type="button" onclick="logout()" value="注销"/>-->


<script src="http://www.mypay.com/static/js/idangerous.swiper.min.js" type="text/javascript" charset="utf-8"></script>

<script>        

var mySwiper = new Swiper('.swiper-container',{

    pagination: '.pagination',

    loop:true,

    grabCursor: true,

    autoplay : 3500,

    autoplayDisableOnInteraction : false,

    paginationClickable: true

})
</script>

<script type="text/javascript" src="http://www.mypay.com/static/js/aspcms_statistics.js"></script>
<div class="foot">
  <div class="foot-1">
     <div class="foot-b">
       <div class="foot-l">
        <ul>


         <!--<li><a href="/web/qhtzi/about/?64.html">企业简介</a></li> -->

         <!--<li><a href="/web/qhtzi/about/?69.html">企业文化</a></li> -->

         <!--<li><a href="/web/qhtzi/about/?67.html">联系我们</a></li> -->

         <!--<li><a href="/web/qhtzi/about/?68.html">法律声明</a></li> -->


        </ul>

        <p>风险提示：</p>
        <p>我们提醒您： 期市有风险，投资需谨慎</p>
        <p>市场风险莫测，务请谨慎行事！</p>
        <p>南京蚩胤电子商务有限公司 Copyright © 2017</p>
       </div>
       <div class="foot-r">
        <span>客服微信：biranhao2019</span>
        <font>工作日 9:00-18:00</font>
        <img src="http://www.mypay.com/static/picture/wz.png">
       </div>
     </div>
  </div>
</div>

 
<div id="ScrollToTop" class="btnimg Button2 WhiteButton">返回<br>顶部</div>

<script>
    $(document).ready(function() {
        var ScrollToTop;
        ScrollToTop = {
            setup: function() {
                var a = $(window).height() / 4;
                $(window).scroll(function() {
                    (window.innerWidth ? window.pageYOffset : document.documentElement.scrollTop) >= a ? $("#ScrollToTop").removeClass("Offscreen") : $("#ScrollToTop").addClass("Offscreen");
                });
                $("#ScrollToTop").click(function() {
                    $("html, body").animate({
                        scrollTop: "0px"
                    }, 1200);
                    return false;
                })
            }
        };

        ScrollToTop.setup();
    });
</script>

</body>
<script>
    window.onload = function(){
        var t = window.setInterval("ajaxData()",3000);
    }
    function ajaxData() {

       $.get('http://ysgj.affeec.com/site/pro-price-list?proNo=hihsif%2Chimhif%2Cbaishatang%2Ccedaxa0%2Cwgcna0%2Cnecla0%2Ccmgca0%2Cyuanyou%2Chushen300%2Cluowengang',function(result)
           {
           // console.log(result['data']);
               $('#baitang').html(result['data']['baishatang']);
               $('#huangjin').html(result['data']['cmgca0']);
               $('#yuanyou').html(result['data']['yuanyou']);
            });

            // 白糖

            $.get('http://ysgj.affeec.com/site/get-hq?proNo=cmgca0&panType=1&pid=34',function(baitang)
            {
                var baitang=JSON.parse( baitang );
                var high ='涨跌最高价格：'+ baitang['resultObject']['model']['high'];
                var low ='涨跌最低价格：'+ baitang['resultObject']['model']['low'];
                $('#baitanghig').html(high);
                $('#baitanglow').html(low);
            }
            );
            // 黄金
            $.get('http://ysgj.affeec.com/site/get-hq?proNo=cmgca0&panType=1&pid=19',function(huangjin)
                {

                    var huangjin=JSON.parse( huangjin );
                    var high ='涨跌最高价格：'+ huangjin['resultObject']['model']['high'];
                    var low ='涨跌最低价格：'+ huangjin['resultObject']['model']['low'];
                    $('#huangjinhig').html(high);
                    $('#huangjinlow').html(low);
                }
            );

           // 原油
            $.get('http://ysgj.affeec.com/site/get-hq?proNo=cmgca0&panType=1&pid=40',function(yuanyou)
                {
                    var yuanyou=JSON.parse( yuanyou );
                    var high ='涨跌最高价格：'+ yuanyou['resultObject']['model']['high'];
                    var low ='涨跌最低价格：'+ yuanyou['resultObject']['model']['low'];
                    $('#yuanyouhig').html(high);
                    $('#yuanyoulow').html(low);
                }
            );
    }

</script>
</html>
