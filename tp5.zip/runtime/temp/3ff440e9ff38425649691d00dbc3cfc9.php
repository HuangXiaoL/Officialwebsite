<?php /*a:1:{s:80:"F:\phpstudy\PHPTutorial\WWW\mypay\tp5\application\index\view\index\userInfo.html";i:1565667601;}*/ ?>
﻿<head>
<html lang="zh-CN">
	<meta charset="utf-8">
<title>赢时国际</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<link href="http://www.mypay.com/static/css/bootstrap.min.css" rel="stylesheet">
	<link href="http://www.mypay.com/static/css/index.css" rel="stylesheet" />
	<link href="http://www.mypay.com/static/css/font-awesome.min.css" rel="stylesheet">
	<link href="http://www.mypay.com/static/css/sweetalert.css" rel="stylesheet">
	<link href="http://www.mypay.com/static/css/components.css" rel="stylesheet">
    <link href="http://www.mypay.com/static/css/common.css" rel="stylesheet">
    <link href="http://www.mypay.com/static/css/front.css" rel="stylesheet" />
	<link href="http://www.mypay.com/static/css/home.css" rel="stylesheet">
	<script type="text/javascript" src="http://www.mypay.com/static/js/jquery-1.10.2.min.js"></script>
	<style>
		
			.dlmain,.pageright{width: initial;}
			.f_l {width: 100%;}
			.liang{color: #aa5800;}
		
	</style>
</head>
<body>
<header>
<div class="container-fluid header-1" >

        <div class="container h1-content" >

            <div class="col-md-5 text-left" >

                <ul>

					<li style="display:none">

						<img src="http://www.mypay.com/static/picture/tel_1.png">服务电话：88888888

					</li>

					<li></li>

                </ul>

            </div>

                       	<div class="col-md-7 text-right">

	                <!--<a href="laws.php">免责声明</a>-->

	                

	               

							

					
							  <a href="userinfo"><?php echo $_SESSION['userData']['nickname'];?></a>

	                <a href="out">退出</a>

							
	              

	            </div>

                   </div>

	</div>

	<div class="container-fluid">

        <div class="container h2-content">

			<div class="pull-left">

				<a href="index.php">

					<img style="width: 206px;" src="http://www.mypay.com/static/picture/logo_1.png" >

				</a>

			</div>

            <div class="pull-right">

               <a class="ground-item" href="index">网站首页</a>


                <a class="ground-item" href="#">个人中心</a>



                <a class="ground-item" href="https://xmvip.vip/L99vQ2">软件下载</a>

				 

               

				

                

            </div>

        </div>

    </div>

<style>

.core a{text-decoration:none;padding: 15px 15px; font-family: '宋体'}

.shell{





width:1140px;

padding:5px 5px 5px 25px; 

	margin-top: 20px;

	margin-bottom: 20px;

}

.core{

height:18px;

position: relative

}

</style>

<div class="shell">

</div>

	 
    	</header>
	<div class="wrap">
		<div class="container" style="margin-top: 50px;">

			<div id="page-content-wrapper">
				<input type="hidden" id="ACTIVE_MENU" value="submeun-1" />

				<div class="box">
					<div class="zhuye-title">我的主页</div>
					<div class="zhuye-zijin" style="height: 140px;    display: table;    padding: 0 10px 0 25px;">
						<div class="pic" onclick="pastpictur()">
							<img class="pointer" src="http://www.mypay.com/static/picture/default-user.jpg"  width="100" height="100"  />
						</div>
						<div class="zijin-right">
							<div class="zijin-title-left">

								<!--<?php dump($_SESSION['userData']['nickname'])?>-->
							<span class="userName" style="font-weight: 700"><?php echo $_SESSION['userData']['nickname'];?></span>
								<br/>&nbsp;

								<span class="money" id="liehou" style="margin-top: 0.3em">
									<?php echo $_SESSION['userData']['mobile'];?>
								</span>


							</div>
						</div>
					</div>
					<div class="HOME">
						<div class="zijin-right-content">
							<!--<div class="ASSET">-->
								<!--<span class="money" id="liehou">-->
									<!--<?php echo $_SESSION['userData']['mobile'];?></span>-->
								<!--<p>手机号</p>-->
							<!--</div>-->
							<div class="mymoney">
								<div class="avalible count">
									<b style="font-weight: 700;font-size: 1.5em">盈利金额（元）：</b>
									<span class="money" id="quanbu">
								<?php echo $_SESSION['userData']['profit_account'];?>
									</span>
								</div>
								<br/>
								<div class="avalible count">
									<b style="font-weight: 700;font-size: 1.5em">当前余额（元）：</b>

									<span class="money" id="quanbu">
									<?php echo $_SESSION['userData']['account'];?>
									</span>
									</span>

								</div>
							</div>
							<div class="frezz">
								<!--<a class="recharge" href="simulated" target="_self" style="margin-right:23px;">入&nbsp;&nbsp;金</a>-->
								<a class="recharge" href="#" target="_self" style="margin-right:23px;">入&nbsp;&nbsp;金</a>
							</div>
						</div>
						<!-- <div class="chart" id="pieChart" ></div> -->
					</div>
					<!-- 我的投资 -->
					<div role="tabpanel" class="tab-pane active" id="investment">
						<div class="navli" style="clear:both;">
							<a href="#investment" style="color: black;">我的交易账号</a>
						</div>
													<div class="alert alert-warning">
								<h3><?php echo $_SESSION['userData']['id'];?></h3>
							</div>

					</div>
				</div>
			</div>
		</div>
	</div>
	

	<script>
	
		$(function(){
			$('.'+$('#ACTIVE_MENU').val()).children().addClass("active");
		});
	
	</script>
   
	
      <div class="footer-2">
            <div class="container">
                <div class="col-md-12" align="center">
                ©&nbsp;2018 赢时国际系统版权所有&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;投资有风险，入市需谨慎
				</div>
              
            </div>
        </div>
	</body>
</html>